# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['slurm']

package_data = \
{'': ['*']}

install_requires = \
['qpro>=0.12.8,<0.13.0', 'quickstart-rhy>=0.7.3,<0.8.0']

entry_points = \
{'console_scripts': ['slurm = slurm.main:main']}

setup_kwargs = {
    'name': 'slurm',
    'version': '0.1.0',
    'description': 'A Slurm Client Tool',
    'long_description': '<h1 style="text-align: center"> slurm </h1>\n\n## Install\n\n```shell\npip3 install slurm -U\n```\n\n## Usage\n\n```shell\nslurm --help\n```\n\n## Developer\n\nIf you need use global config, just edit `__config__.py`:\n\n1. make `enable_config = True`.\n2. edit `questions` list.\n3. using `config` at `main.py`.\n',
    'author': 'Rhythmicc',
    'author_email': 'rhythmlian.cn@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
