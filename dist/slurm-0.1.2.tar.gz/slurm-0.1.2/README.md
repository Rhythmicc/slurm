<h1 style="text-align: center"> slurm </h1>

## Install

```shell
pip3 install git+https://github.com/Rhythmicc/slurm.git -U
```

## Usage

```shell
slurm # show help
```
